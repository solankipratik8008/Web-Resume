//
//  ViewController.swift
//  PratikKumar_Solanki_MID_9043621
//
//  Created by user268835 on 2/27/25.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var CityText: UITextField!
    
    @IBOutlet weak var CityButton: UIButton!
    let cityImages: [String: String] = [
        "toronto": "toronto.jpeg",
        "halifax": "halifax.jpeg",
        "montreal": "montreal.jpeg",
        "calgary": "calgary.jpeg",
        "vancouver":"Vancouver.jpeg",
        "winnipeg":"Winnipeg.jpeg"
        
    ]
    let cityColors: [String: UIColor] = [
        "toronto": .systemMint,
           "halifax": .systemTeal,
           "montreal": .systemRed,
           "calgary": .systemOrange,
           "vancouver": .systemGreen,
           "winnipeg": .systemPurple
       ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setupUI()
       
    }
    func setupUI() {
        CityButton.layer.cornerRadius = 10
        CityText.borderStyle = .roundedRect
    }
    @IBOutlet weak var CityImage: UIImageView!
    
    @IBAction func CityButton(_ sender: Any) {
        guard let cityName = CityText.text?.lowercased(),
              let imageName = cityImages[cityName] else {
            CityImage.image = UIImage(named: "placeholder.jpg")
            return
            
            
            
            
            
            
        }
        
        CityImage.image = UIImage(named: imageName)
        
        
        if let bgColor = cityColors[cityName] {
                   self.view.backgroundColor = bgColor
               } else {
                   self.view.backgroundColor = .white // Default color if city has no assigned color
               }
    }
    
    
    
    
    
    
//
//        
//        
//        
//        
//        
//    }
//    
    
    
    
    
    
    
    
    
    
    
}
