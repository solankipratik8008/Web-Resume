//
//  Buttonview.swift
//  PratikKumar_Solanki_MID_9043621
//
//  Created by user268835 on 2/27/25.
//

import UIKit

class Buttonview: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        MYsetupUI()
    }
    
    @IBOutlet weak var Resultlabel: UILabel!
    
   
    @IBOutlet weak var Atext: UITextField!
    
    @IBOutlet weak var BText: UITextField!
    
    
    
    
       func MYsetupUI() {
           // Set initial UI properties
           Resultlabel.text = ""
           self.view.backgroundColor = UIColor.systemYellow
           Atext.keyboardType = .numberPad
           BText.keyboardType = .numberPad
           lbl1.text = "Enter The Value for A And B To Find C"
           
       }
    
    
    @IBOutlet weak var lbl1: UILabel!
    @IBAction func calculate(_ sender: Any) {
        guard let aText = Atext.text, let a = Double(aText),
              let bText = BText.text, let b = Double(bText) else {
            Resultlabel.text = "Please enter valid numbers!"
                   return
               }
               
               let c = sqrt(a * a + b * b)  // Pythagoras formula
        
        lbl1.text = "The Value Of C Accoring To Pythagores is "
        
        Resultlabel.text = " \(c)"
        
        
        
        
    }
    
    
    
    
    
    
    @IBAction func Clearbtn(_ sender: Any) {
        
        
        Atext.text = ""
        BText.text = ""
        Resultlabel.text = ""
        
        
        
        
    }
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    
    

}
